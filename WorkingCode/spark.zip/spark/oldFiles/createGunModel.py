from pyspark import SparkContext
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.tree import RandomForest
import time
sc = SparkContext(appName="Create_Models")

def parsePoint(line):
  values = line.split(',')
  return LabeledPoint(values[0], values[1:])


gunfileNameTrain = 'train.csv'
gunfileNameTest = 'test.csv'
gun_train = sc.textFile(gunfileNameTrain)
gun_test = sc.textFile(gunfileNameTest)

#skip header
gun_header = gun_train.first() #extract header
gun_train = gun_train.filter(lambda x:x !=gun_header)
#filter out header using a lambda
print gun_train.first()

gun_labeledPoints = gun_train.map(parsePoint)
#Split the data into training and test sets (30% held out for testing)
(gun_trainingData, gun_testData) = gun_labeledPoints.randomSplit([0.7, 0.3])
print gun_train.first()

depthLevel = 4
treeLevel = 3
#start timer
gun_start_time = time.time()
#this is building a model using the Random Forest algorithm from Spark MLLib
gun_model = RandomForest.trainClassifier(gun_trainingData, numClasses=10,
  categoricalFeaturesInfo={},
  numTrees=treeLevel, featureSubsetStrategy="auto",
  impurity='gini', maxDepth=depthLevel, maxBins=32)
print("Training time --- %s seconds ---" % (time.time() - start_time))


# Evaluate model on test instances and compute test error
#start timer
gun_start_time = time.time()
#make predictions using the Machine Learning created prior
gun_predictions = model.predict(testData.map(lambda x: x.features))
#validate predictions using the training set
gsun_labelsAndPredictions = gun_testData.map(lambda lp: lp.label).zip(gun_predictions)
gun_testErr = gun_labelsAndPredictions.filter(lambda (v, p): v != p).count() / float(gun_testData.count())
print('Test Error = ' + str(gun_testErr))
print("Prediction time --- %s seconds ---" % (time.time() - gun_start_time))
#print('Learned classification tree model:')
#print(model.toDebugString())

gun_bestModel = None
gun_bestTestErr = 100
#Define a range of hyperparameters to try
maxDepths = range(4,10)
maxTrees = range(3,10)

#Loop over parameters for depth and tree level(s)
for depthLevel in maxDepths:
 for treeLevel in maxTrees:

  #start timer
  gun_start_time = time.time()
  #Train RandomForest machine learning classifier
  gun_model = RandomForest.trainClassifier(gun_trainingData,
    numClasses=10, categoricalFeaturesInfo={},
    numTrees=treeLevel, featureSubsetStrategy="auto",
    impurity='gini', maxDepth=depthLevel, maxBins=32)

  #Make predictions using the model created above
  gun_predictions = gun_model.predict(gun_testData.map(lambda x: x.features))
  #Join predictions with actual values from the data and determine the error rate
  gun_labelsAndPredictions = gun_testData.map(lambda lp: lp.label).zip(gun_predictions)
  gun_testErr = gun_labelsAndPredictions.filter(lambda (v, p): v != p).count() / float(gun_testData.count())

  #Print information about the model as we proceed with each iteration of the loop
  print ('\maxDepth = {0:.1f}, trees = {1:.1f}: trainErr = {2:.5f}'
         .format(depthLevel, treeLevel, gun_testErr))
  print("Prediction time --- %s seconds ---" % (time.time() - gun_start_time))
  if (gun_testErr < gun_bestTestErr):

      gun_bestModel = gun_model
      gun_bestTestErr = gun_testErr

print ('Best Test Error: = {0:.3f}\n'.format(gun_bestTestErr))



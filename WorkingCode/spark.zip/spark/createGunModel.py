from pyspark import SparkContext
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.classification import NaiveBayes
import pickle

sc = SparkContext(appName="DataPrediction")

gunAdvocate = sc.textFile("/home/ubuntu/SavvyIndependent/GunModel/supportGunControl")
gunOpponent = sc.textFile("/home/ubuntu/SavvyIndependent/GunModel/opposeGunControl") 

gunAdvocate_words = gunAdvocate.map(lambda bill: bill.split())
gunOpponent_words = gunOpponent.map(lambda bill: bill.split())

tf = HashingTF(numFeatures = 1000)
gunAdvocate_features = tf.transform(gunAdvocate_words)
gunOpponent_features = tf.transform(gunOpponent_words)

gunAdvocate_samples = gunAdvocate_features.map(lambda features:LabeledPoint(1, features))
gunOpponent_samples = gunOpponent_features.map(lambda features:LabeledPoint(0, features))

samples = gunAdvocate_samples.union(gunOpponent_samples)
[training_data, test_data] = samples.randomSplit([0.8, 0.2])
training_data.cache()
test_data.cache()

algo = NaiveBayes()
model = algo.train(training_data)
predictions = model.predict(test_data.map(lambda x: x.features))
labels_and_preds = test_data.map(lambda x: x.label).zip(predictions)
accuracy = labels_and_preds.filter(lambda x: x[0] == x[1]).count() / float(test_data.count())

print ("Accuracy: " + str(accuracy) + "%")
pickle.dump(model, open("/home/ubuntu/SavvyIndependent/GunModel/model", "wb"))

from pyspark import SparkContext
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.tree import RandomForest
from pyspark.mllib.classification import LogisticRegressionWithSGD
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.classification import NaiveBayes, NaiveBayesModel
import time
import pickle
import requests
import json


class Bill:
    def __init__(self, text):
        self.text = text
    def getText():
        tf = HashingTF(nimFeatures=1000)
        return tf.transform(text.split(" "))
    def votedYes(congressman):
        placehold

sc = SparkContext(appName="CreatePredictions")


tf = HashingTF(numFeatures = 1000)
model = pickle.load( open( "model", "rb" ) )


gunAdvocateExample = tf.transform("For the sake of the children, this bill aims to limit firearms sales in the United States which will ensure all of our safety".split(" "))
gunOpponentExample = tf.transform("We propose that silencers be legalized at the federal level, and owners will not be required to register their silencers".split(" "))

print(model.predict(gunAdvocateExample))
print(model.predict(gunOpponentExample))

bills = [] # list of bill objects
headers = {
        'x-api-key' : 'WQXjxcLrtedzCdldj4WTjJu3YXIVavd6DWXZBZ2w3'
        }
if not "gun" in 
info_gun = requests.get("https://api.propublica.org/congress/v1/115/house/sessions/2/votes/1", headers = headers)
json_response = json.loads(info_gun.text)
i = 0
while i < len(json_response['results']):
    text = json_response['results']['bills']['summary']
    session = json_response['result']['bills']['bill_id']


congressmen #list of congressmen
gunAdvocate #boolean
bills.


agree = 0
disagree = 0
for bill in bills:
    prediction = model.predict(bill.getText()))
    for congressman in congressmen:
        if prediction == 1.0 and gunAdvocate:
            if bill.votedYes(congressman):
                agree += 1
            else: disagree += 1
        elif prediction == 1.0 and not gunAdvocate:
            if bill.votedYes(congressman):
                disagree += 1
            else: agree += 1
        elif prediction == 0.0 and gunAdvocate:
            if bill.votedYes(congressman):
                disagree += 1
            else: agree += 1
        elif prediction 0.0 and not gunAdvocate:
            if bill.votedYes(congressman):
                agree += 1
            else: disagree += 1

agreement = agree / float(agree+disagree)

#Write agreement percentage to the correct place in mySQL database



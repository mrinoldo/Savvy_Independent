<?php
  $q1output = $_POST['q1'];
  $q2output = $_POST['q2'];
  $q3output = $_POST['q3'];
  $q4output = $_POST['q4'];
  $q5output = $_POST['q5'];

  echo $q1output;
  echo $q2output;
  echo $q3output;
  echo $q4output;
  echo $q5output;
?>

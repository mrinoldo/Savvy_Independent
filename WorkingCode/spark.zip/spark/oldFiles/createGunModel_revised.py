from pyspark import SparkContext
from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.tree import RandomForest
from pyspark.mllib.classification import LogisticRegressionWithSGD
from pyspark.mllib.feature import HashingTF
from pyspark.mllib.classification import NaiveBayes, NaiveBayesModel
import time
import pickle
sc = SparkContext(appName="GunControlModel")


oppose_gc = sc.textFile('opposeGunControl')
support_gc = sc.textFile('supportGunControl')

#print(spam_mails.collect())

features = HashingTF(numFeatures = 1000)

Features_support = support_gc.map(lambda mail:features.transform(mail.split(" ")))
Features_oppose = oppose_gc.map(lambda mail:features.transform(mail.split(" ")))

positive_data = Features_support.map(lambda features:LabeledPoint(1, features))
negative_data = Features_oppose.map(lambda features:LabeledPoint(0, features))

data = positive_data.union(negative_data)
data.cache()
training, test = data.randomSplit([0.6, 0.4])

logistic_Learner = LogisticRegressionWithSGD()
model = logistic_Learner.train(training, iterations=100)

predictionLabel = test.map(lambda x:(model.predict(x.features),x.label))

print (predictionLabel.collect())
accuracy1 = 1.0 * predictionLabel.filter(lambda x: x[0] == x[1]).count() / training.count()
print"Accuracy is: %f" %(accuracy1)

pickle.dump(model, open( "model", "wb"))
